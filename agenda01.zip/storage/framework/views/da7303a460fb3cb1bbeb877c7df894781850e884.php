
<?php $__env->startSection('title', $persona ? 'Editar Persona' : 'Nueva Persona'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2><?php echo e($persona ? 'Editar Persona' : 'Nueva Persona'); ?></h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e($persona ? url('/persona/'.$persona->id) : url('/persona')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre"
                   value="<?php echo e($persona->nombre ?? ''); ?>" placeholder="Ingrese su nombre">
        </div>

        <div class="mb-3">
            <label for="apellido" class="form-label">Apellido</label>
            <input type="text" class="form-control" id="apellido" name="apellido"
                   value="<?php echo e($persona->apellido ?? ''); ?>" placeholder="Ingrese su apellido">
        </div>

        <div class="mb-3">
            <label for="edad" class="form-label">Edad</label>
            <input type="number" class="form-control" id="edad" name="edad"
                   value="<?php echo e($persona->edad ?? ''); ?>" placeholder="Ingrese su edad">
        </div>

        <button type="submit" class="btn btn-primary">
            <?php echo e($persona ? 'Actualizar' : 'Guardar'); ?>

        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agenda\resources\views/persona/form.blade.php ENDPATH**/ ?>