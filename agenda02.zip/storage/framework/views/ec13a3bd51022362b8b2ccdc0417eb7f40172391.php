
<?php $__env->startSection('title', 'Listado de Personas'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Listado de Personas</h2>
    <a href="<?php echo e(url('/db_persona/nueva')); ?>" class="btn btn-primary mb-3">Nuevo</a>
   

    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>E-mail</th>
                <th>Edad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($persona->id); ?></td>
                <td><?php echo e($persona->nombre); ?></td>
                <td><?php echo e($persona->email); ?></td>
                <td><?php echo e($persona->edad); ?></td>
                <td>
                    <a href="<?php echo e(url('/db_persona/'.$persona->id.'/editar')); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <a href="<?php echo e(url('/db_persona/'.$persona->id.'/eliminar')); ?>" class="btn btn-danger btn-sm">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\agenda\resources\views/persona_db/index.blade.php ENDPATH**/ ?>